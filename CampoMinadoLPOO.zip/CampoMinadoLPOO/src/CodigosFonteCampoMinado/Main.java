package CodigosFonteCampoMinado;





import InterfaceCampoMinado.Cronometro;
import InterfaceCampoMinado.InterfaceTabuleiro;


public class Main {

	public static void main(String[] args) {
		
		  
		InterfaceTabuleiro i = new InterfaceTabuleiro();
		  Cronometro Cronometro = new Cronometro(i);
			
		
			
		  
		
		

	}
	public static void resetGeral() {
		
		  InterfaceTabuleiro i = new InterfaceTabuleiro();

		 Cronometro Cronometro = new Cronometro(i);
		  
		
	}
}