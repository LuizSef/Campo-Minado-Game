module CampoMinadoLPOO {
	requires java.desktop;
}